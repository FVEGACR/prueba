#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface FPhiUCFrameObj : NSObject

@property (nonatomic) CGContextRef context;
@property (nonatomic) CGRect bounds;

@end
